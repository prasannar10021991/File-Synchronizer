package filesync;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class SyncServer {

	
	@Option(name = "-file", aliases = { "--input" }, required = true,
            usage = "input file")
	private String source;
	
	@Option(name = "-host", aliases = { "--hostname" }, required = false,
            usage = "connection host")
	private String host;
	
	@Option(name = "-p", aliases = { "--port" }, required = false,
            usage = "port")
	private int port;
	
	private boolean errorFree = false;
 
	public SyncServer(String... args) {
	        CmdLineParser parser = new CmdLineParser(this);
	        parser.setUsageWidth(80);
	        try {
	            parser.parseArgument(args);

	          
	            errorFree = true;
	        } catch (CmdLineException e) {
	            System.err.println(e.getMessage());
	            parser.printUsage(System.err);
	        }
	    }

	 public boolean isErrorFree() {
	        return errorFree;
	    }

	    /**
	     * Returns the source file.
	     *
	     * @return The source file.
	     */
	    public String getSource() {
	        return source;
	    }
	    public String getHost() {
	        return host;
	    }
	    public int getPort() {
	        return port;
	    }
	   
	public static void main(String[] args) {
		
		SynchronisedFile toFile=null;
		SyncServer values = new  SyncServer(args);
		String negotiation = "";
		int blocksize = 1024;
		
		JSONParser parser1 = new JSONParser();
		DatagramSocket socket2;
		try {
			socket2 = new DatagramSocket(values.getPort());
			byte[] buf = new byte[2048];
			DatagramPacket check2 = new DatagramPacket(buf,buf.length);
			socket2.receive(check2);
			String chkData2 =new String(check2.getData(),check2.getOffset(),check2.getLength());
			JSONObject json10 = (JSONObject)parser1.parse(chkData2);
			negotiation = json10.get("dir").toString();
			//System.out.println(negotiation+"sajbdkajs");
		    blocksize = Integer.parseInt(json10.get("block").toString());
			
			
			String chkData = negotiation;
			
			JSONObject json4 = new JSONObject();
			json4.put("dir", chkData);
			InetAddress hello = InetAddress.getByName(values.getHost());
		
			String sendmsg = json4.toJSONString();
			byte[] buf4 = sendmsg.getBytes();
			DatagramPacket check = new DatagramPacket(buf4,buf4.length,check2.getAddress(),check2.getPort());
			//System.out.println(negotiation+"sajb");
			
			socket2.send(check);
			socket2.close();
			
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		// Now you can use the command line values
		try {
	
			toFile = new SynchronisedFile(values.getSource());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(negotiation.equals("push"))
		{
			if(values.getPort()!=0)
			{
				
				if(values.getHost()!=null)
	        	{
	        		Thread serverThread = new Thread(new SyncTestThread3(toFile,values.getPort(),values.getHost()));
	        		serverThread.start();
	        	}
	        	else
	        	{
	        		Thread serverThread = new Thread(new SyncTestThread3(toFile,values.getPort(),"localhost"));
	        		serverThread.start();
	        	}
		
			}
			else
			{
				if(values.getHost()!=null)
	    		{
	    			Thread serverThread = new Thread(new SyncTestThread3(toFile,4144,values.getHost()));
	    			serverThread.start();
	    		}
	    		else
	    		{
	    			Thread serverThread = new Thread(new SyncTestThread3(toFile,4144,"localhost"));
	    			serverThread.start();
	    		}
	    		
		
			}
		}
		else
		{

        	if(values.getPort()!=0)
            {
            	if(values.getHost()!=null)
            	{
            		Thread clientThread = new Thread(new ServPushThread(toFile,values.getHost(),values.getPort(),blocksize));
            		clientThread.start();
            	}
            	else
            	{
            		Thread clientThread = new Thread(new ServPushThread(toFile,"localhost",values.getPort(),blocksize));
            		System.out.print("client");
            		clientThread.start();
            		
            	}
            	
        		
            }
            else
            {	if(values.getHost()!=null)
        		{
        			Thread clientThread = new Thread(new ServPushThread(toFile,values.getHost(),4144,blocksize));
        			clientThread.start();
        		}
        		else
        		{
        			Thread clientThread = new Thread(new ServPushThread(toFile,"localhost",4144,blocksize));
        			clientThread.start();
        		}
        		
            }
        	
        	while(true){
    			try {
    				// TODO: skip if the file is not modified
    				System.err.println("SyncTest: calling fromFile.CheckFileState()");
    				toFile.CheckFileState();
    			} catch (IOException e) {
    				e.printStackTrace();
    				System.exit(-1);
    			} catch (InterruptedException e) {
    				e.printStackTrace();
    				System.exit(-1);
    			}
    			try {
    				Thread.sleep(5000);
    			} catch (InterruptedException e) {
    				e.printStackTrace();
    				System.exit(-1);
    			}
    		}
			
			
		}
		

		
		
	}
	
	
}
