package filesync;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ClientPullThread implements Runnable
{
	
	SynchronisedFile toFile;
	public static int port ;
	public static InetAddress host ;
	ClientPullThread(SynchronisedFile tf,int num,String hostname)
	{
		toFile=tf;
		port = num;
		try {
			host = InetAddress.getByName(hostname);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void run() 
	{
		long serverCounter = 0;
		JSONParser parser1 = new JSONParser();
		JSONObject json1 = new JSONObject();
		InstructionFactory instructFact = new InstructionFactory();
		DatagramSocket socket = null;

		try 
		{
			
			socket = new DatagramSocket(port);
			/*byte[] buf = new byte[1024];
			DatagramPacket check = new DatagramPacket(buf,buf.length);
			socket.receive(check);
			String chkData =new String(check.getData());
			System.out.println(chkData);
			
			if(chkData.equals("push"))
			{*/
				
				System.out.println("Server is running...");
				while (true)
				{
					
					serverCounter++; 
					byte[] buf1 = new byte[2048];
					DatagramPacket packet1 = new DatagramPacket(buf1, buf1.length);
					socket.receive(packet1);
					String reqData = new String(packet1.getData(), packet1.getOffset(), packet1.getLength());			
					try 
					{
						json1 = (JSONObject)parser1.parse(reqData);
					} 
					catch (ParseException e1) 
					{
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if (json1.get("Type").equals("StartUpdate"))
					{
						serverCounter = 1;
					}
					long receivedCounter = (long) json1.get("counter");
					if((receivedCounter)==(serverCounter))
					{
						json1.put("Type","ack");
						json1.put("counter",serverCounter);
					}
					else
					{
						json1.put("Type","expecting");
						json1.put("counter",serverCounter);
					}
					Instruction instruction2 = instructFact.FromJSON(reqData);
					try 
					{
						toFile.ProcessInstruction(instruction2);
					} 
					catch (IOException e) 
					{
						e.printStackTrace();
						System.exit(-1); 
					}
					catch (BlockUnavailableException e) 
					{
						json1.put("Type", "exception");
						json1.put("counter", serverCounter);
						String msg = json1.toJSONString();
						byte[] Buf2 = msg.getBytes();
						DatagramPacket response = new DatagramPacket(Buf2, Buf2.length,packet1.getAddress(),packet1.getPort());
						socket.send(response);
						packet1 = new DatagramPacket(buf1, buf1.length);
						socket.receive(packet1);
						reqData= new String(packet1.getData(), packet1.getOffset(), packet1.getLength());			
						json1.put("Type","ack");
						json1.put("counter",serverCounter);
						instruction2 = instructFact.FromJSON(reqData);
						try
						{
							toFile.ProcessInstruction(instruction2);
						}
						catch (IOException e1) 
						{
							e.printStackTrace();
							System.exit(-1); 
						} 
						catch (BlockUnavailableException e1) 
						{
							assert(false);
						}
						
					} 
					finally 
					{
						String msg = json1.toJSONString();
						byte[] Buf3 = msg.getBytes();
						DatagramPacket response= new DatagramPacket(Buf3, Buf3.length,packet1.getAddress(),packet1.getPort());
						socket.send(response);
					}
				}//while
		
			
			
			
		/*	
			else
			{
				Instruction inst;
				JSONObject json6 = new JSONObject();
				JSONObject json2 = new JSONObject();
				JSONParser parse1 = new JSONParser();
				JSONParser parse2 = new JSONParser();
				long clientCounter = 0; 
				DatagramSocket socket = null;
				
				while((inst=toFile.NextInstruction())!=null)
				{
					String msg=inst.ToJSON();
					System.err.println("Sending: "+msg);
					
					try
					{
						socket = new DatagramSocket();
										
						try
						{
							json6 = (JSONObject)parse1.parse(msg);
						} 
						catch (ParseException e) 
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if(json6.get("Type").equals("StartUpdate"))
						{
							clientCounter = 0;
						}
						
						clientCounter++;
						json6.put("counter", clientCounter);
						String msg1=json6.toJSONString();
						byte[] cbuf = msg1.getBytes();
						DatagramPacket request = new DatagramPacket(cbuf, cbuf.length, host, port);
						socket.send(request);

						byte[] cbuf2 = new byte[1024];
						DatagramPacket reply = new DatagramPacket(cbuf2, cbuf2.length);
						socket.receive(reply);
						String repData = new String(reply.getData(), reply.getOffset(), reply.getLength());	
						json2 = (JSONObject) parse2.parse(repData);
						String type = json2.get("Type").toString();
						
						if (type.equals("exception"))
						{
						
							Instruction upgraded=new NewBlockInstruction((CopyBlockInstruction)inst);
							String msg2 = upgraded.ToJSON();
							System.err.println("Sending: "+msg2);
							byte[] cbuf3 = new byte[1024];
							cbuf3 = msg2.getBytes();
							DatagramPacket request2 = new DatagramPacket(cbuf3, cbuf3.length, host, port);
							socket.send(request2);
							byte[] cbuf4 = new byte[1024];
							DatagramPacket reply2 = new DatagramPacket(cbuf4, cbuf4.length);
							socket.receive(reply2);
							
						}
						else if (type.equals("expecting"))
						{
							long ackCounter = (long) json2.get("counter");
							if (ackCounter < clientCounter)
							{
								clientCounter = ackCounter;
								json2.put("counter",clientCounter);
								String msg3 = json2.toJSONString();
								byte[] cbuf5 = msg3.getBytes();
								DatagramPacket request3 = new DatagramPacket(cbuf5, cbuf5.length, host, port);
								socket.send(request3);
								byte[] cbuf6 = new byte[1024];
								DatagramPacket reply3 = new DatagramPacket(cbuf6, cbuf6.length);
								socket.receive(reply3);
								
							}
							
						}
					} 
					catch (SocketException e)
					{
						e.printStackTrace();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
					catch (ParseException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					finally 
					{
						if (socket!=null)
						{
							socket.close();
						}

					}
				}
			}//else
			*/
			
		}//try
		catch (SocketException e)
		{
			 e.printStackTrace();
		}
		catch (IOException e)
		{
		   e.printStackTrace();
		}
		finally 
		{
			if (socket!=null)
			{
				socket.close();
			}
		}
	}	
}


