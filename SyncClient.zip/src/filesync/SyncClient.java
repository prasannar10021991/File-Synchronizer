package filesync;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

/**
 * This class handles the programs arguments.
 */
public class SyncClient {
	
    
	@Option(name = "-file", aliases = { "--input" }, required = true,
            usage = "input file")
	private String source;
	
	@Option(name = "-host", aliases = { "--hostname" }, required = false,
            usage = "connection host")
	private String host;
	
	@Option(name = "-p", aliases = { "--port" }, required = false,
            usage = "port")
	private int port;
	
	@Option(name = "-b", aliases = { "--size" }, required = true,
            usage = "blocksize")
	private int blocksize;
	
	@Option(name = "-d", aliases = { "--direction" }, required = true,
            usage = "direction")
	private String direction;
	
	
	
	
	
    private boolean errorFree = false;

    public SyncClient(String... args) {
        CmdLineParser parser = new CmdLineParser(this);
        parser.setUsageWidth(80);
        try {
            parser.parseArgument(args);
            if ((getDirection().equals("push")||getDirection().equals("pull"))!=true) {
                throw new CmdLineException(parser,
                        "--direction should be either push or pull");}
            
            errorFree = true;
        } catch (CmdLineException e) {
            System.err.println(e.getMessage());
            parser.printUsage(System.err);
        }
    }

    /**
     * Returns whether the parameters could be parsed without an
     * error.
     *
     * @return true if no error occurred.
     */
    public boolean isErrorFree() {
        return errorFree;
    }

    /**
     * Returns the source file.
     *
     * @return The source file.
     */
    public String getSource() {
        return source;
    }
    public String getHost() {
        return host;
    }
    public int getPort() {
        return port;
    }
    public int getBlocksize() {
        return blocksize;
    }
    public String getDirection() {
        return direction;
    }
    
   
    
    public static void main(String[] args) {
    	SynchronisedFile fromFile = null;
    	
        SyncClient values = new  SyncClient(args);
        String negotiation = values.getDirection();
        DatagramSocket socket2= null;
        try {
        	JSONParser parser1 = new JSONParser();
			socket2 = new DatagramSocket();
			String chkData = values.getDirection();
			JSONObject json4 = new JSONObject();
			json4.put("dir", chkData);
			json4.put("block", values.getBlocksize());
			InetAddress hello = InetAddress.getByName(values.getHost());
			String sendmsg = json4.toJSONString();
			byte[] buf4 = sendmsg.getBytes();
			DatagramPacket check = new DatagramPacket(buf4,buf4.length,hello,values.getPort());
			socket2.send(check);
			
			byte[] buf = new byte[2048];
			DatagramPacket check2 = new DatagramPacket(buf,buf.length);
			socket2.receive(check2);
			String chkData2 =new String(check2.getData(),check2.getOffset(),check2.getLength());
			JSONObject json10 = (JSONObject)parser1.parse(chkData2);
			negotiation = json10.get("dir").toString();
			System.out.println(negotiation);
			socket2.close();
			
			
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
         // Now you can use the command line values
        try {
        	//System.out.print(values.getHost());
			fromFile = new SynchronisedFile(values.getSource());
			//,values.getBlocksize()
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        
        if(values.getDirection().equals("push"))
        {
        	if(values.getPort()!=0)
            {
            	if(values.getHost()!=null)
            	{
            		Thread clientThread = new Thread(new SyncTestThread2(fromFile,values.getHost(),values.getPort(),values.getBlocksize()));
            		clientThread.start();
            	}
            	else
            	{
            		Thread clientThread = new Thread(new SyncTestThread2(fromFile,"localhost",values.getPort(),values.getBlocksize()));
            		System.out.print("client");
            		clientThread.start();
            		
            	}
            	
        		
            }
            else
            {	if(values.getHost()!=null)
        		{
        			Thread clientThread = new Thread(new SyncTestThread2(fromFile,values.getHost(),4144,values.getBlocksize()));
        			clientThread.start();
        		}
        		else
        		{
        			Thread clientThread = new Thread(new SyncTestThread2(fromFile,"localhost",4144,values.getBlocksize()));
        			clientThread.start();
        		}
        		
            }
        	
        	while(true){
    			try {
    				// TODO: skip if the file is not modified
    				System.err.println("SyncTest: calling fromFile.CheckFileState()");
    				fromFile.CheckFileState();
    			} catch (IOException e) {
    				e.printStackTrace();
    				System.exit(-1);
    			} catch (InterruptedException e) {
    				e.printStackTrace();
    				System.exit(-1);
    			}
    			try {
    				Thread.sleep(5000);
    			} catch (InterruptedException e) {
    				e.printStackTrace();
    				System.exit(-1);
    			}
    		}
        	
        }
        else if(values.getDirection().equals("pull"))
        {
        	if(values.getPort()!=0)
            {
            	if(values.getHost()!=null)
            	{
            		Thread clientThread = new Thread(new ClientPullThread(fromFile,values.getPort(),values.getHost()));
            		clientThread.start();
            	}
            	else
            	{
            		Thread clientThread = new Thread(new ClientPullThread(fromFile,values.getPort(),"localhost"));
            		clientThread.start();
            	}
            	
        		
            }
            else
            {	if(values.getHost()!=null)
        		{
        			Thread clientThread = new Thread(new ClientPullThread(fromFile,4144,values.getHost()));
        			clientThread.start();
        		}
        		else
        		{
        			Thread clientThread = new Thread(new ClientPullThread(fromFile,4144,"localhost"));
        			clientThread.start();
        		}
        		
            }
        }
        
        
		/*
		 * Continue forever, checking the fromFile every 5 seconds.
		 */
	
      
    }
    
}