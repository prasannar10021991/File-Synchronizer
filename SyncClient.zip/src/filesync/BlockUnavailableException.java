/**
 * 
 */
package filesync;

/**
 * @author aaron
 * @date 7th April 2013
 */

public class BlockUnavailableException extends Exception {

	/**
	 * 
	 */
	public BlockUnavailableException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public BlockUnavailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public BlockUnavailableException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BlockUnavailableException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
