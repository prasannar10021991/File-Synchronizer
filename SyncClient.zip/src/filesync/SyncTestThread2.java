package filesync;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class SyncTestThread2 implements Runnable
{
	
	SynchronisedFile fromFile;
	public static int port;
	public static InetAddress host ;
	public static int blocksize;
	public static String direction;
	SyncTestThread2(SynchronisedFile ff,String hostname,int num,int block)
	{
		fromFile=ff;
		port = num;
		try {
			host = InetAddress.getByName(hostname);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		blocksize = block;
		direction = "push";
	}
	
	SyncTestThread2(SynchronisedFile ff,String hostname,int num,int block,String dir)
	{
		fromFile=ff;
		port = num;
		try {
			host = InetAddress.getByName(hostname);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		blocksize = block;
		direction = dir;
	}
	
	@SuppressWarnings("unchecked")
	public void run()
	{
		if(direction.equals("push"))
		{
			Instruction inst;
			JSONObject json1 = new JSONObject();
			JSONObject json2 = new JSONObject();
			JSONParser parse1 = new JSONParser();
			JSONParser parse2 = new JSONParser();
			long serverCounter = 0; 
			/*DatagramSocket socket2 = null;

			try {
				socket2 = new DatagramSocket();
				String chkData = direction;
				byte[] buf1 = chkData.getBytes();
				DatagramPacket check = new DatagramPacket(buf1,buf1.length,host,port);
				socket2.send(check);
								
			} catch (SocketException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				socket2.close();
			}*/
			while((inst=fromFile.NextInstruction())!=null)
			{
				String msg=inst.ToJSON();
				System.err.println("Sending: "+msg);
				DatagramSocket socket = null;
				try
				{
					socket = new DatagramSocket();
									
					try
					{
						json1 = (JSONObject)parse1.parse(msg);
					} 
					catch (ParseException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(json1.get("Type").equals("StartUpdate"))
					{
						serverCounter = 0;
					}
					
					serverCounter++;
					json1.put("counter", serverCounter);
					String msg1=json1.toJSONString();
					byte[] buf = msg1.getBytes();
					DatagramPacket request = new DatagramPacket(buf, buf.length, host, port);
					socket.send(request);

					byte[] buf2 = new byte[1024];
					DatagramPacket reply = new DatagramPacket(buf2, buf2.length);
					socket.receive(reply);
					String repData = new String(reply.getData(), reply.getOffset(), reply.getLength());	
					json2 = (JSONObject) parse2.parse(repData);
					String type = json2.get("Type").toString();
					
					if (type.equals("exception"))
					{
					
						Instruction upgraded=new NewBlockInstruction((CopyBlockInstruction)inst);
						String msg2 = upgraded.ToJSON();
						System.err.println("Sending: "+msg2);
						byte[] buf3 = new byte[1024];
						buf3 = msg2.getBytes();
						DatagramPacket request2 = new DatagramPacket(buf3, buf3.length, host, port);
						socket.send(request2);
						byte[] buf4 = new byte[1024];
						DatagramPacket reply2 = new DatagramPacket(buf4, buf4.length);
						socket.receive(reply2);
						
					}
					else if (type.equals("expecting"))
					{
						long ackCounter = (long) json2.get("counter");
						if (ackCounter < serverCounter)
						{
							serverCounter = ackCounter;
							json2.put("counter",serverCounter);
							String msg3 = json2.toJSONString();
							byte[] buf5 = msg3.getBytes();
							DatagramPacket request3 = new DatagramPacket(buf5, buf5.length, host, port);
							socket.send(request3);
							byte[] buf6 = new byte[1024];
							DatagramPacket reply3 = new DatagramPacket(buf6, buf6.length);
							socket.receive(reply3);
							
						}
						
					}
				} 
				catch (SocketException e)
				{
					e.printStackTrace();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				catch (ParseException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally 
				{
					if (socket!=null)
					{
						socket.close();
					}

				}
			}	
			
		}//if direction
		
		/*else
		{	DatagramSocket socket2 = null;
			try {
				
				socket2 = new DatagramSocket();
				String chkData = direction;
				byte[] buf1 = chkData.getBytes();
				DatagramPacket check = new DatagramPacket(buf1,buf1.length,host,port);
				socket2.send(check);
								
			} catch (SocketException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				socket2.close();
			}
			long clientCounter = 0;
			JSONParser parser1 = new JSONParser();
			JSONObject json7 = new JSONObject();
			
			InstructionFactory instructFact = new InstructionFactory();
			DatagramSocket socket = null;

			try 
			{
				
				socket = new DatagramSocket(port);
				
					System.out.println("Server is running...");
					while (true)
					{
						clientCounter++; 
						byte[] sbuf1 = new byte[1024];
						DatagramPacket packet1 = new DatagramPacket(sbuf1, sbuf1.length);
						socket.receive(packet1);
						String reqData = new String(packet1.getData(), packet1.getOffset(), packet1.getLength());			
						try 
						{
							json7 = (JSONObject)parser1.parse(reqData);
						} 
						catch (ParseException e1) 
						{
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						if (json7.get("Type").equals("StartUpdate"))
						{
							clientCounter = 1;
						}
						long receivedCounter = (long) json7.get("counter");
						if((receivedCounter)==(clientCounter))
						{
							json7.put("Type","ack");
							json7.put("counter",clientCounter);
						}
						else
						{
							json7.put("Type","expecting");
							json7.put("counter",clientCounter);
						}
						Instruction instruction2 = instructFact.FromJSON(reqData);
						try 
						{
							fromFile.ProcessInstruction(instruction2);
						} 
						catch (IOException e) 
						{
							e.printStackTrace();
							System.exit(-1); 
						}
						catch (BlockUnavailableException e) 
						{
							json7.put("Type", "exception");
							json7.put("counter",clientCounter);
							String msg = json7.toJSONString();
							byte[] Buf2 = msg.getBytes();
							DatagramPacket response = new DatagramPacket(Buf2, Buf2.length,packet1.getAddress(),packet1.getPort());
							socket.send(response);
							packet1 = new DatagramPacket(sbuf1, sbuf1.length);
							socket.receive(packet1);
							reqData= new String(packet1.getData(), packet1.getOffset(), packet1.getLength());			
							json7.put("Type","ack");
							json7.put("counter",clientCounter);
							instruction2 = instructFact.FromJSON(reqData);
							try
							{
								fromFile.ProcessInstruction(instruction2);
							}
							catch (IOException e1) 
							{
								e.printStackTrace();
								System.exit(-1); 
							} 
							catch (BlockUnavailableException e1) 
							{
								assert(false);
							}
							
						} 
						finally 
						{
							String msg = json7.toJSONString();
							byte[] Buf3 = msg.getBytes();
							DatagramPacket response= new DatagramPacket(Buf3, Buf3.length,packet1.getAddress(),packet1.getPort());
							socket.send(response);
						}
					}//while
				
				
				
			}//try
			catch (SocketException e)
			{
				 e.printStackTrace();
			}
			catch (IOException e)
			{
			   e.printStackTrace();
			}
			finally 
			{
				if (socket!=null)
				{
					socket.close();
				}
			}
			
			
			
			
			
			
		}//else */
		
	}//run
}//class
